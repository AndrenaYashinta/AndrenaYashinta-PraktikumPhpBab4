<!DOCTYPE html>
<html>
<head>
	<title>Aplikasi CRUD</title>
</head>
<body>
	<h1>Data Siswa</h1>
	<a href="form_simpan.php">Tambah Data</a><br><br>
	<table border="1" width="100%">
	<tr>
		<th>Foto</th>
		<tr>NIS</tr>
		<tr>Nama</tr>
		<tr>Jenis Kelamin</tr>
		<tr>Telepon</tr>
		<tr>Alamat</tr>
		<th colspan="2">Aksi</th>
	</tr>
	<?php
	include"koneksi_php";
	$sql=mysql_query($connect,"SELECT * FROM siswa");

	while($data=mysqli_fetch_array($sql)){
		echo"<tr>";
		echo"<td><img_src='".$data['Foto']."'width='100' height='100'></td>;
		echo"<td>".$data['NIS']."</td>;
		echo"<td>".$data['Nama']."</td>;
		echo"<td>".$data['Jenis_Kelamin']."</td>;
		echo"<td>".$data['Telp']."</td>;
		echo"<td>".$data['Alamat']."</td>;
		echo"<td><a href='form_ubah.php?nis=".$data['NIS']."'>Ubah</a></td>";
		echo"<td><a href='proses_hapus.php?nis=".$data['NIS']."'>Hapus</a></td>";
		echo"</tr>";
	}
	?>
</table>
</body>
</html>